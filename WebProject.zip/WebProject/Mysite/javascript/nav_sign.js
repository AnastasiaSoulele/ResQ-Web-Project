function login() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
  window.location.href = '/html/login.html';
}

function register() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
  window.location.href = '/html/login.html';
}
