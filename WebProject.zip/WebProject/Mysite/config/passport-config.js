const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');

function initialize(passport, sqlClient) {
  const authenticateUser = async (username, password, done) => {
    try {
      // Αναζήτηση χρήστη από τον πίνακα users με βάση το username
      sqlClient.query('SELECT * FROM users WHERE username = ?', [username], async (err, users) => {
        if (err) return done(err);
        if (users.length === 0) return done(null, false, { message: 'No user with that username' });

        const user = users[0];

        try {
          // Έλεγχος εάν το password είναι σωστό
          if (await bcrypt.compare(password, user.password)) {
            if (!user.user_type) {
              return done(null, false, { message: 'Unknown user type' });
            }
            return done(null, user);  // Επιστροφή του χρήστη εάν το password είναι σωστό
          } else {
            return done(null, false, { message: 'Password incorrect' });
          }
        } catch (e) {
          return done(e);
        }
      });
    } catch (e) {
      return done(e);
    }
  };

  passport.use(new LocalStrategy({ usernameField: 'username' }, authenticateUser));

  // **SerializeUser**: Αποθήκευση των δεδομένων του χρήστη στο session
  passport.serializeUser((user, done) => {
    const sessionUser = {
      id: user.user_id,  // Το πραγματικό user_id
      userType: user.user_type,  // Ο τύπος του χρήστη (admin, rescuer, citizen)
    };
    console.log('Serialized user:', sessionUser);  // Log για να δούμε τι αποθηκεύεται στο session
    done(null, sessionUser);
  });
  
  
  
  passport.deserializeUser((sessionUser, done) => {
    console.log('Deserializing user:', sessionUser);  // Log για να δούμε τι υπάρχει στο session

    const { userType, id } = sessionUser;
  
    if (!userType || !id) {
      return done(new Error('Invalid session data'));
    }
  
    let query = '';
    if (userType === 'admin') {
      query = 'SELECT * FROM admin WHERE admin_id = ?';
    } else if (userType === 'rescuer') {
      query = 'SELECT * FROM rescuer WHERE rescuer_id = ?';
    } else if (userType === 'citizen') {
      query = 'SELECT * FROM citizen WHERE citizen_id = ?';
    } else {
      return done(new Error('Unknown user type'));
    }
  
    sqlClient.query(query, [id], (err, users) => {
      if (err) return done(err);
      if (users.length === 0) return done(new Error('User not found'));
  
      console.log('Found user:', users[0]);  // Log για τον χρήστη που ανακτήθηκε
      return done(null, users[0]);
    });
  });
  
}

module.exports = initialize;
