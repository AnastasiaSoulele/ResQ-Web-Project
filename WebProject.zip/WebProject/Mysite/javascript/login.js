document.addEventListener('DOMContentLoaded', function() {

  // LOGIN FUNCTIONS
  document.getElementById("loginForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (!username || !password) {
      alert('Συμπληρώστε και τα δύο πεδία');
      return;
    }

    // Εμφάνιση μηνύματος αναμονής ή spinner
    document.getElementById("loginBtn").innerText = "Logging in...";

    loginUser(username, password);
  });

  async function loginUser(username, password) {
    try {
      const response = await fetch("http://localhost:3000/signin", {
        credentials: "include",
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password }),
      });

      // Επαναφορά του κειμένου του κουμπιού μετά την απάντηση
      document.getElementById("loginBtn").innerText = "Login";

      console.log('Response status:', response.status);

      if (response.ok) {
        const result = await response.json();
        if (result.redirectUrl) {
          window.location.href = result.redirectUrl;  // Ανακατεύθυνση στη σωστή σελίδα
        } else {
          alert('Login successful, but no redirect URL provided.');
        }
      } else {
        const errorMessage = await response.json();  // Αν δεν είναι επιτυχές το response, διάβασε το μήνυμα
        console.error('Login failed:', errorMessage);
        alert(`Login failed: ${errorMessage.message}`);
      }
    } catch (error) {
      console.error("Error during login:", error);
      alert("An error occurred during login.");
    }
  }

// REGISTER FUNCTIONS
document.getElementById("registerForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const username = document.getElementById("registerUsername").value;
  const email = document.getElementById("registerEmail").value;
  const password = document.getElementById("registerPassword").value;
  const firstname = document.getElementById("firstname").value;
  const lastname = document.getElementById("lastname").value;
  const phoneNumber = document.getElementById("phoneNumber").value;
  const termsAccepted = document.getElementById("accept-terms").checked;

  // Έλεγχος αν όλα τα πεδία είναι συμπληρωμένα
  if (!username || !password || !email || !firstname || !lastname || !phoneNumber) {
    alert('Συμπληρώστε όλα τα πεδία');
    return;
  }

  if (!termsAccepted) {
    alert('Πρέπει να αποδεχτείτε τους Όρους και Προϋποθέσεις');
    return;
  }

  registerUser({ username, email, password, firstname, lastname, phoneNumber });
});

async function registerUser(data) {
  try {
    const response = await fetch("http://localhost:3000/signup", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data),
    });

    if (response.ok) {
      const result = await response.json();
      if (result.success) {
        window.location.href = `citizen.html?username=${data.username}`;
      } else {
        alert('Registration failed. Please try again.');
      }
    } else {
      const errorMessage = (await response.json()).message;
      alert(`Registration failed: ${errorMessage}`);
    }
  } catch (error) {
    console.error(error);
    alert("An error occurred during registration.");
  }
}

});

function myMenuFunction() {
  var i = document.getElementById("navMenu");
  if (i.className === "nav-menu") {
    i.className += " responsive";
  } else {
    i.className = "nav-menu";
  }
}

var a = document.getElementById("loginBtn");
var b = document.getElementById("registerBtn");
var x = document.getElementById("login");
var y = document.getElementById("register");

function login() {
  console.log({ username, password });
  x.style.left = "4px";
  y.style.right = "-520px";
  a.className += " white-btn";
  b.className = "btn";
  x.style.opacity = 1;
  y.style.opacity = 0;
  document.getElementById('login').style.transform = 'translateX(0)';
  document.getElementById('register').style.transform = 'translateX(100%)';

  window.scrollTo({ top: 0, behavior: 'smooth' });
}


function register() {
  x.style.left = "-510px";
  y.style.right = "5px";
  a.className = "btn";
  b.className += " white-btn";
  x.style.opacity = 0;
  y.style.opacity = 1;
  document.getElementById('login').style.transform = 'translateX(-100%)';
  document.getElementById('register').style.transform = 'translateX(0)';

  window.scrollTo({ top: 0, behavior: 'smooth' });
}


  function donate() {
    window.location.href = '/html/donate.html';
  }
  



