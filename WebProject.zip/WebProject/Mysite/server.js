if (process.env.NODE_ENV !== 'production') {
  require('dotenv').config();
}

const express = require('express');
const bcrypt = require('bcrypt');
const session = require('express-session');
const methodOverride = require('method-override');
const sqlClient = require('./config/sqlclient');
const path = require('path');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const passport = require('passport');
const initializePassport = require('./config/passport-config');

const app = express();
const PORT = 3000;


app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});

// Middleware setup
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(cors({ origin: true , credentials: true }));
app.use(methodOverride('_method'));

// Static files (εικόνες, CSS, JavaScript)

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'html')));
app.use(express.static(path.join(__dirname, 'assets')));  // Αν έχεις φάκελο `assets` για εικόνες, CSS, κλπ.

// Session configuration
app.use(session({
  secret: process.env.SECRET_KEY || 'your-secret-key',
  resave: false,
  saveUninitialized: false,  // Βεβαιώσου ότι το session δεν αποθηκεύεται αν δεν έχει αυθεντικοποίηση
  cookie: {
    maxAge: 1000 * 60 * 45, // 45 λεπτά
    secure: false,          // Αν χρησιμοποιείς τοπική ανάπτυξη, το κάνουμε false
    httpOnly: true
  }
}));



// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Initialize passport with custom config
initializePassport(passport, sqlClient);

app.use((req, res, next) => {
  console.log('Session data:', req.session);
  next();
});

// Cache headers
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});



// Routes
// Routes για τα HTML αρχεία
app.get('/html/login.html', checkNotAuthenticated, (req, res) => {
  console.log('Serving login.html');
  res.sendFile(path.join(__dirname, 'html', 'login.html'));
});

// Admin route - Έλεγχος αν είναι admin
app.get('/html/admin.html', checkAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'html', 'admin.html'));
});

app.get('/html/rescuer.html', checkAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'html', 'rescuer.html'));
});

app.get('/html/citizen.html', checkAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'html', 'citizen.html'));
});


// Dynamic route για οποιοδήποτε άλλο αρχείο HTML
app.get('/:pageName.html', (req, res) => {
  res.sendFile(path.join(__dirname, `html/${req.params.pageName}.html`));
});

// Route για CSS αρχεία
app.get('/:styleName.css', (req, res) => {
  res.sendFile(path.join(__dirname, `assets/${req.params.styleName}.css`));  // Αν τα CSS είναι στον φάκελο assets
});

// Route για JavaScript αρχεία
app.get('/:scriptName.js', (req, res) => {
  res.sendFile(path.join(__dirname, `javascript/${req.params.scriptName}.js`));
});


app.post('/signin', (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) return next(err);
    if (!user) return res.status(401).json({ message: 'Invalid username or password' });
    
    req.logIn(user, (err) => {
      if (err) return next(err);
      
      // Εδώ σιγουρευόμαστε ότι αποθηκεύουμε το σωστό user στον session
      console.log('Logged in user:', req.user);

      // Redirect ανάλογα με τον τύπο χρήστη
      if (user.user_type === 'admin') {
        return res.json({ redirectUrl: '/html/admin.html' });
      } else if (user.user_type === 'rescuer') {
        return res.json({ redirectUrl: '/html/rescuer.html' });
      } else if (user.user_type === 'citizen') {
        return res.json({ redirectUrl: '/html/citizen.html' });
      }

      return res.status(400).json({ message: 'Unknown user type' });
    });
  })(req, res, next);
});




/*------------------Sign up-------------------*/

app.post('/signup', async (req, res) => {
  try {
    const { username, email, password, firstname, lastname, phoneNumber } = req.body;

    sqlClient.query('SELECT * FROM citizen WHERE username_citizen = ?', [username], async (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'Something went wrong!' });
      }

      if (results.length > 0) return res.status(400).json({ message: 'User already exists!' });

      // Hash the password
      const hash = bcrypt.hashSync(password, 10);

      // Insert into citizen table
      sqlClient.query('INSERT INTO citizen (username_citizen, password_citizen, citizen_name, citizen_lname, ph_number, citizen_email) VALUES (?, ?, ?, ?, ?, ?)', [username, hash, firstname, lastname, phoneNumber, email], (err, results) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'Something went wrong!' });
        }

        console.log({ results });
        return res.status(200).json({ success: true, username });
      })  
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Something went wrong' });
  }
});



/*-------------------RESCUER--------------------*/

app.get('/rescuer-profile', checkAuthenticated ,async (req, res) => {
  console.log('User in session:', req.user); 

   const rescuer_id = req.user.rescuer_id;

  try {
    // Ανάκτηση πληροφοριών για τον rescuer
    const [rescuerInfo] = await sqlClient.promise().query(
      'SELECT username_res AS name FROM rescuer WHERE rescuer_id = ?',
      [rescuer_id]
    );

    if (rescuerInfo.length === 0) {
      return res.status(404).json({ message: 'Rescuer not found' });
    }
    // Ανάκτηση του πλήθους των ενεργών tasks (Accepted ή In progress)
    const [taskCount] = await sqlClient.promise().query(
      `SELECT COUNT(*) AS tasks 
       FROM tasks t
       LEFT JOIN requests r ON t.task_id = r.req_task_id
       LEFT JOIN offers o ON t.task_id = o.offer_task_id
       WHERE t.rescuer_id = ? 
       AND (r.req_status IN ('Accepted', 'In progress') OR o.offer_status IN ('Accepted', 'In progress'))`,
      [rescuer_id]
    );
    const rescuer = {
      name: rescuerInfo[0].name,
      tasks: taskCount[0].tasks
    };
    res.status(200).json(rescuer);
  } catch (error) {
    console.error('Error fetching rescuer profile:', error);
    res.status(500).json({ message: 'Failed to fetch rescuer profile' });
  }
});





// Logout route
app.delete('/logout', (req, res) => {
  console.log('Logging out user:', req.session.userId);
  
  req.logout((err) => {
    if (err) {
      console.error('Logout error:', err);
      return res.status(500).json({ message: 'Failed to log out' });
    }
    req.session.destroy(() => {
      res.status(200).json({ message: 'Successful logout', redirectUrl: '/html/login.html' });
    });
  });
});


// Middleware functions
function checkAuthenticated(req, res, next) {
  console.log('Checking authentication:', req.isAuthenticated());
  console.log('User data from session:', req.user);
  
  if (req.isAuthenticated()) {
    return next();
  }
  
  console.log('User is not authenticated, redirecting to login.');
  res.redirect('/html/login.html');
}



function checkNotAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    console.log('User is already authenticated, redirecting to home.');

    // Ελέγχουμε τον τύπο του χρήστη και κάνουμε το ανάλογο redirect
    if (req.user.userType === 'admin') {
      return res.redirect('/html/admin.html');
    } else if (req.user.userType === 'rescuer') {
      return res.redirect('/html/rescuer.html');
    } else if (req.user.userType === 'citizen') {
      return res.redirect('/html/citizen.html');
    }

    return res.redirect('/html/login.html'); // Αν δεν υπάρχει τύπος χρήστη
  }
  next();
}


