//Rescuer
document.addEventListener('DOMContentLoaded', function () {
  const profileBtn = document.getElementById('profile-btn');
  const profileSidebar = document.getElementById('profile-sidebar');
  
  profileBtn.addEventListener('click', async function () {
    profileSidebar.classList.toggle('active');
    if (profileSidebar.classList.contains('active')) {
      try {
        const response = await fetch('http://localhost:3000/rescuer-profile');
        if (response.ok) {
          const rescuer = await response.json();
          document.getElementById('rescuer-name').textContent = rescuer.name || 'Rescuer Name';
          document.getElementById('rescuer-info').textContent = `Tasks: ${rescuer.tasks}` || 'Additional info here...';
          
        } else {
          console.error('Failed to load rescuer profile.');
        }
      } catch (error) {
        console.error('Error fetching rescuer profile:', error);
      }
    }
  });


});
