document.addEventListener('DOMContentLoaded', async function () {
  const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');
  const allContentSections = document.querySelectorAll('.content-section');
  await fetchAndDisplayTasks();

  // Διαχείριση πλοήγησης στο sidebar
  allSideMenu.forEach(item => {
      const li = item.parentElement;

      item.addEventListener('click', function () {
          const sectionId = item.getAttribute('data-section');
          allSideMenu.forEach(i => {
              i.parentElement.classList.remove('active');
          });
          li.classList.add('active');

          // Εμφάνιση της αντίστοιχης ενότητας περιεχομένου
          allContentSections.forEach(content => {
              content.classList.remove('active');
          });
          document.getElementById(sectionId + '-content').classList.add('active');
      });
  });



 //--------------------Info Rescuer-------------------------//


   try {
    const response = await fetch('http://localhost:3000/rescuer-profile', {
        method: 'GET',
        credentials: 'include',
        cache: 'no-store'
    });

        const rescuer = await response.json();
        document.getElementById('notification-count').textContent = rescuer.tasks;
   
} catch (error) {
    console.error('Error fetching rescuer profile:', error);
}

});
