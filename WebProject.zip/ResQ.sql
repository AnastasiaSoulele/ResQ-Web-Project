

DROP TABLE IF EXISTS `admin`;
DROP TABLE IF EXISTS `announcement`;
DROP TABLE IF EXISTS `tasks`;
DROP TABLE IF EXISTS `rescuer_tasks`;
DROP TABLE IF EXISTS `vehicle_inventory`;
DROP TABLE IF EXISTS `requests`;
DROP TABLE IF EXISTS `offers`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `rescuer`;
DROP TABLE IF EXISTS `vehicles`;
DROP TABLE IF EXISTS `citizen_cords`;
DROP TABLE IF EXISTS `citizen`;
DROP TABLE IF EXISTS `worker_cords`;
DROP TABLE IF EXISTS `worker`;
DROP TABLE IF EXISTS `category`;
DROP TABLE IF EXISTS `base`;




-- Create the base table
CREATE TABLE `base` (
  `base_username` varchar(25) NOT NULL,
  `base_region` varchar(25) NOT NULL,
  `base_lat` float NOT NULL,
  `base_lng` float NOT NULL,
  PRIMARY KEY (`base_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create the category table
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create the worker table
CREATE TABLE `worker` (
  `wrk_id` int NOT NULL AUTO_INCREMENT,
  `wrk_name` varchar(25) NOT NULL DEFAULT 'not defined',
  `wrk_lname` varchar(25) NOT NULL DEFAULT 'not defined',
  `wrk_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`wrk_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Create the worker_cords table
CREATE TABLE `worker_cords` (
  `wrk_id` int NOT NULL,
  `wrk_lat` float DEFAULT NULL,
  `wrk_lng` float DEFAULT NULL,
  PRIMARY KEY (`wrk_id`),
  CONSTRAINT `worker_cords_ibfk_1` FOREIGN KEY (`wrk_id`) REFERENCES `worker` (`wrk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create the citizen table
CREATE TABLE `citizen` (
  `citizen_id` int NOT NULL AUTO_INCREMENT,
  `username_citizen` varchar(35) NOT NULL DEFAULT 'user',
  `password_citizen` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'password',
  `citizen_name` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `citizen_lname` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ph_number` char(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `citizen_region` varchar(25) NOT NULL DEFAULT 'not defined',
  `citizen_email` varchar(100) NOT NULL,
  PRIMARY KEY (`citizen_id`, `username_citizen`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create the citizen_cords table
CREATE TABLE `citizen_cords` (
  `ctzen_id` int NOT NULL,
  `ctzen_lat` float DEFAULT NULL,
  `ctzen_lng` float DEFAULT NULL,
  PRIMARY KEY (`ctzen_id`),
  CONSTRAINT `citizen_cords_ibfk_1` FOREIGN KEY (`ctzen_id`) REFERENCES `citizen` (`citizen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create admin table
CREATE TABLE `admin` (
  `admin_id` int NOT NULL,
  `username_adm` varchar(35) NOT NULL DEFAULT 'user',
  `password_adm` varchar(150) NOT NULL DEFAULT 'password',
  PRIMARY KEY (`admin_id`, `username_adm`),
  CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `worker` (`wrk_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Create the rescuer table
CREATE TABLE `rescuer` (
  `rescuer_id` int NOT NULL,
  `username_res` varchar(35) NOT NULL DEFAULT 'user',
  `password_res` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'password',
  `vehicle` int UNIQUE,                             -- This field represents the vehicle, which is unique for each rescuer
  PRIMARY KEY (`rescuer_id`),
  CONSTRAINT `RESCUER` FOREIGN KEY (`rescuer_id`) REFERENCES `worker` (`wrk_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Create the vehicles table with a reference to the vehicle field in the rescuer table
CREATE TABLE `vehicles` (
  `vehicle_id` int AUTO_INCREMENT,
  PRIMARY KEY (`vehicle_id`),
  CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `rescuer` (`vehicle`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



-- Create the products table
CREATE TABLE `products` (
  `prod_id` int NOT NULL AUTO_INCREMENT,
  `prod_category_id` int DEFAULT NULL,
  `prod_item` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `prod_description` varchar(255) DEFAULT NULL,
  `totalQuantity` float DEFAULT NULL,
  `prod_category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`prod_id`),
  UNIQUE KEY `prod_item` (`prod_item`),
  KEY `prod_category_id` (`prod_category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`prod_category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create the tasks table
CREATE TABLE `tasks` (
  `task_id` int NOT NULL AUTO_INCREMENT,
  `task_prod_id` int NOT NULL,
  `task_type` enum('Request','Offer') DEFAULT NULL,
  `rescuer_id` int DEFAULT NULL,
  PRIMARY KEY (`task_id`),
  KEY `task_prod_id` (`task_prod_id`),
  KEY `FK_tasks_rescuer` (`rescuer_id`),
  CONSTRAINT `FK_tasks_rescuer` FOREIGN KEY (`rescuer_id`) REFERENCES `rescuer` (`rescuer_id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`task_prod_id`) REFERENCES `products` (`prod_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create the offers tableθ
CREATE TABLE `offers` (
  `offer_task_id` int NOT NULL AUTO_INCREMENT,
  `offer_citizen_id` int NOT NULL,
  `offer_date_record` datetime NOT NULL,
  `offer_date_withdraw` datetime DEFAULT NULL,
  `offer_quantity` float NOT NULL,
  `offer_vehicle_id` int,
  `offer_status` enum('Accepted','Denied','Cancelled','In progress','Completed') DEFAULT NULL,
  `offer_item` varchar(50) NOT NULL,
  PRIMARY KEY (`offer_task_id`),
  KEY `offer_citizen_id` (`offer_citizen_id`),
  CONSTRAINT `OFFER` FOREIGN KEY (`offer_task_id`) REFERENCES `tasks` (`task_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offers_ibfk_1` FOREIGN KEY (`offer_citizen_id`) REFERENCES `citizen` (`citizen_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Create requests table
CREATE TABLE `requests` (
  `req_task_id` int NOT NULL AUTO_INCREMENT,
  `req_citizen_id` int NOT NULL,
  `req_date_record` datetime NOT NULL,
  `req_date_withdraw` datetime DEFAULT NULL,
  `req_quantity` float NOT NULL,
  `req_vehicle_id` int,
  `req_status` enum('Accepted', 'Denied', 'Cancelled', 'In progress', 'Completed') DEFAULT NULL,
  `req_item` varchar(50) NOT NULL,
  `req_num_person` int unsigned,
  PRIMARY KEY (`req_task_id`),
  CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`req_task_id`) REFERENCES `tasks` (`task_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create rescuer_tasks table
CREATE TABLE `rescuer_tasks` (
  `rescuer_id` int NOT NULL,
  `task_id` int NOT NULL,
  `task_lat` float DEFAULT NULL,
  `task_lng` float DEFAULT NULL,
  PRIMARY KEY (`rescuer_id`, `task_id`),
  CONSTRAINT `rescuer_tasks_ibfk_1` FOREIGN KEY (`rescuer_id`) REFERENCES `rescuer` (`rescuer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rescuer_tasks_ibfk_2` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`task_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create vehicle_inventory table
CREATE TABLE `vehicle_inventory` (
  `prod_id` int DEFAULT NULL,
  `quantity` float DEFAULT '0',
  `vehicle_id` int NOT NULL,
  UNIQUE KEY `unique_vehicle_product` (`vehicle_id`, `prod_id`),
  CONSTRAINT `vehicle_inventory_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`vehicle_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `vehicle_inventory_ibfk_2` FOREIGN KEY (`prod_id`) REFERENCES `products` (`prod_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Create announcement table
CREATE TABLE `announcement` (
  `announcement_id` INT NOT NULL AUTO_INCREMENT,
  `announcement_cat_id` INT,
  `announcement_prod_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `status` ENUM('Accepted', 'Denied', 'Cancelled', 'In progress', 'Completed','Posted') DEFAULT 'In progress' NOT NULL,
  PRIMARY KEY (`announcement_id`),
  CONSTRAINT `announcement_ibfk_1` FOREIGN KEY (`announcement_cat_id`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `announcement_ibfk_2` FOREIGN KEY (`announcement_prod_id`) REFERENCES `products` (`prod_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Inserts 

-- Base table inserts
INSERT INTO `base` (`base_username`, `base_region`, `base_lat`, `base_lng`) VALUES 
('Βάση Α', 'Volos', 0.0, 0.0);

ALTER TABLE category AUTO_INCREMENT = 1;


INSERT INTO category (name) VALUES
('Food and Water'),
('Electronics'),
('Medicine'),
('Clothing and Textiles'),
('Personal Hygiene'),
('First Aid and Medical Supplies'),
('Communication Devices'),
('Power Generation and Lighting'),
('Tools and Equipment'),
('Baby and Childcare'),
('Pet Care'),
('Cleaning and Sanitation'),
('Furniture and Appliances'),
('Recreational and Leisure');

ALTER TABLE worker AUTO_INCREMENT = 1

-- Insert into worker table
INSERT INTO `worker` (`wrk_name`, `wrk_lname`, `wrk_email`) VALUES
('Αναστασία', 'Σουλελέ', 'anastasia.soulele@example.com'),
('Βασιλική', 'Νασιέλη', 'vasiliki.nasieli@example.com'),
('Χαρίτων', 'Κικίδης', 'chariton.kikidis@example.com'),
('Παναγιώτης', 'Ζάγκος', 'panagiotis.zagkos@example.com'),
('Αναστάσης', 'Κιουτσιούκης', 'anastasis.kioutsioukis@example.com'),
('Κωσταντίνος', 'Βασιλακόπουλος', 'kostas.vasilakopoulos@example.com'),
('Πασχάλης', 'Βενετίδης', 'paschalis.venetidis@example.com'),
('Νικολία', 'Φίλια', 'nikolia.filia@example.com'),
('Πολυξένη', 'Τσιργιάννη', 'polyxeni.tsirgiani@example.com'),
('Ελευθερία', 'Ευσταθείου', 'eleutheria.eustathiou@example.com');

-- Insert into worker_cords table
INSERT INTO worker_cords (wrk_id, wrk_lat, wrk_lng) VALUES
(1, 39.3532, 22.9787),
(2, 39.3618, 22.9267),
(3, 39.3453, 22.9267),
(4, 39.3434, 22.8765),
(5, 39.5653, 22.9887),
(6, 39.3093, 22.4567),
(7, 39.6553, 22.9227),
(8, 39.3953, 22.8765),
(9, 39.1453, 22.9767),
(10, 39.3432, 22.8967);


ALTER TABLE citizen AUTO_INCREMENT = 1

-- Insert into citizen table
INSERT INTO `citizen` (`username_citizen`, `password_citizen`, `citizen_name`, `citizen_lname`, `ph_number`, `citizen_region`, `citizen_email`) VALUES
('kostaskont', '$2b$16$kUtuliZw9rQJYFp4cLdqkekrbXR3t.0aL7tF7x.JL1iuiN46sGNDq', 'Κωσταντίνος', 'Κονταρίδης', '6949537804', 'Πάτρα', 'kostiskond@gmail.com'),
('mariapap', '$2b$16$BsDaor9MjR0cTDxF1WDBCeNoMrsPZoX.l72d/c2Ltx/2tX/Lwj6X6', 'Μαρία', 'Παπαδάκη', '6949537805', 'Αθήνα', 'mariapap@gmail.com'),
('giorgosbour', '$2b$16$dt9MhnC3d0lNga.9nGbLC.H9UBPR7zNGxinubndGSUb6SVWsNEPaW', 'Γιώργος', 'Βουρλούμης', '6949537806', 'Βόλος', 'georgebour@gmail.com'),
('tatianasoul', '$2b$16$Y9lgwTbiC7q3twF5XAfv4ewpQZulNzK54nU2IXdifMbfE.3taYCgC', 'Τατιάνα', 'Σουλελέ', '6949537807', 'Θεσσαλονίκη', 'tatsoul@gmail.com'),
('nickmav', '$2b$16$u1YxCJOxyCuAo6Zt0y3WjOQ9F4lcIo829tRD9Y5x4c2rbB/CjaLMe', 'Νικόλας', 'Μαυριάς', '6949537808', 'Πάτρα', 'nikmav@gmail.com'),
('billmpar', '$2b$16$5XBjVJc29ZT9RIKpWXBfKOryTXSjQXGSHbdt4Jx9UXocavjHiZKGS', 'Βασίλης', 'Μπαρδάκης', '6949537809', 'Λάρισα', 'billbill@gmail.com'),
('theoplat', '$2b$16$xqY0QNSmerSmDtcxUQUErO2/XFfkpVcXUQFr9Z/C9r33RyGMVuwfu', 'Θεόδωρος', 'Πλάτωνας', '6949537810', 'Λάρισα', 'theoplat@gmail.com'),
('andreassoul', '$2b$16$1NGGXk49/7ka6PqdqwMXL.zFnlKJttYUUpi4HJyBmgI.puDyj1BTG', 'Ανδρέας', 'Σουλελές', '6949537811', 'Λάρισα', 'andresoul@gmail.com'),
('ioaschoina', '$2b$16$oe5moYNF4k2kRdTj.vyDdOxLhiKekEMJdkWzvNzTz1j5hWLPYSs8q', 'Ιωάννα', 'Σχοινά', '6949537812', 'Λαμία', 'ioaschoina@gmail.com'),
('stavrosmpa', '$2b$16$Ih6Z4J49TR0HjGUAgmdWWua/4RN0rrifmcSqROIXUb/LBYGAFBNFy', 'Σταύρος', 'Μπαντζής', '6949537813', 'Αλμυρός', 'stavrosmpa@gmail.com'),
('mirtokost', '$2b$16$B50Rwk224tWtu8zgYeUW2ewUDTS1brMMxgzYQIRDtOL73M5tN9mGa', 'Μυρτώ', 'Κωστούλια', '6949537814', 'Αθήνα', 'mirtokost@gmail.com'),
('minadiam', '$2b$16$6Kx8740gPuqWj55MkPOdQOGIpTw9viKVGGwSZT07rRhAAJbpnkEuK', 'Γερασιμίνα', 'Διαμαντάτου', '6949537815', 'Καρδίτσα', 'minadiam@gmail.com'),
('ioanalmt', '$2b$16$.L565n9KR.ZWES0lOVE4DOpypPK95wrk28CdnvhvpsiaiYU1uFJeK', 'Ιωάννα', 'Λυμιώτη', '6949537816', 'Πάτρα', 'ioannalmt@gmail.com'),
('andrianamix', '$2b$16$8jImOxbqPcTsdPvISDseyOq0iYB0I5.vWRIUEv5.4cjvte0encLr.', 'Ανδριάνα', 'Μιχαλοπούλου', '6949537817', 'Αθήνα', 'andrianamix@gmail.com'),
('hliaszagk', '$2b$16$G/Ona3i8yJ1Z.c/C8jP92.vLXpJCaPS6Fl5Jn.Vxa9XAcXwMZleT.', 'Ηλίας', 'Ζάγκος', '6949537818', 'Βόλος', 'hliaszagk@gmail.com'),
('alexpanag', '$2b$16$oRzR6i6yz2mdO8jOCj/kIei8XAHFon2FrXCr8jTR.EQzPEbkGoxfO', 'Αλεξάνδρα', 'Πανάγου', '6949537819', 'Πάτρα', 'alexpanag@gmail.com');

-- Insert into citizen_cords table
INSERT INTO resq.citizen_cords (ctzen_id, ctzen_lat, ctzen_lng) 
VALUES
(1, 39.3793, 22.9466),
(2, 39.3728, 22.9059),
(3, 39.3679, 22.9227),
(4, 39.3650, 22.9558),
(5, 39.3873, 22.9225),
(6, 39.3845, 22.9230),
(7, 39.3645, 22.9558),
(8, 39.3900, 22.9600),
(9, 39.3413, 22.9350),
(10, 39.3516, 22.9629),
(11, 39.3631, 22.8865),
(12, 39.3809, 22.8976),
(13, 39.3894, 22.9306),
(14, 39.3499, 22.9969),
(15, 39.3660, 22.9240),
(16, 39.3495, 22.9198);


ALTER TABLE admin AUTO_INCREMENT = 1;

-- Insert into admin table
INSERT INTO `admin` (`admin_id`, `username_adm`, `password_adm`) VALUES
(9, 'poltsirgiani', '$2b$08$05S8dUB3DOKle.gGtb7IgO/CvMcOYSgUynZvJsjxYHgswyVSlolLy'),
(10, 'eleutheriaeustatheiou', '$2b$08$bb/zowAUQ5RiYtSiuKISd.gf46QXg.IVopMjKjhywO6vUcOyZi/S6');


ALTER TABLE rescuer AUTO_INCREMENT = 1;

-- Insert into rescuer table
INSERT INTO `rescuer` (`rescuer_id`, `username_res`, `password_res`, `vehicle`) VALUES
(1, 'anastasiasoulele', '$2b$08$N45btUssiYHsbjIc4Ll4ee8kr8uGu34l6BR32ma5/DCidqkQlatHK', 1),
(2, 'vasilikinasieli', '$2b$08$2/q1M2oH5e/u3BjQdT53B.MUhvF1cXTd6IrKIwSG5mqlcudJeGuWG', 2),
(3, 'charitonkikidis', '$2b$08$LUTKr.6oUyGp37Ez6PvVHeUTrv3hHgRWw2R/9vJ4CxM7y/LOH/nL.', 3),
(4, 'panagiotiszagkos', '$2b$08$BkjP0AxWd7Rbcl/ny56izeSpDDqTLK5xw8P1Jis1upnjk.HUU3AJK', 4),
(5, 'anastasis_kioutsioukis', '$2b$08$SS6d/P6jW1TinQV0dP3Uzu1l/4JT06QnvonibWi/Vel/clK2sT9lW', 5),
(6, 'kostvasilakopoulos', '$2b$08$dCmeJVuoRaMz.A9jmFE7nuXBxbuz348YDwbfmjYtLcFX1jcd5Yw/a', 6),
(7, 'pasxalisven', '$2b$08$jvZmQy/s9imPda/h2318eequceB5KrbEYk09FGN0aq6NVS70qTwUW', 7),
(8, 'nikoliafilia', '$2b$08$E.BJuti0ZW6MOpua.ncZX.0ZfJutpX0XyNBdhAfrGi6Au9CdzaDtq', 8);


ALTER TABLE vehicles AUTO_INCREMENT = 1;

-- Insert into vehicles table
INSERT INTO `vehicles` (`vehicle_id`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8);


ALTER TABLE products AUTO_INCREMENT = 1;

-- Insert into products table for missing categories
INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Food and Water
(1, 'Canned Beans', 'Long-lasting canned beans for emergency food supply.', 150.0, 'Food and Water'),
(1, 'Bottled Water', 'Packaged water bottles for drinking.', 300.0, 'Food and Water'),
(1, 'Rice', '5kg bags of white rice', 300, 'Food and Water'),
(1, 'Pasta', '1kg packs of dry pasta', 600, 'Food and Water'),
(1, 'Dried Lentils', '1kg bags of dried lentils', 250, 'Food and Water'),
(1, 'Instant Noodles', 'Packs of instant noodles', 800, 'Food and Water'),
(1, 'Energy Bars', 'High-protein energy bars', 450, 'Food and Water'),
(1, 'Canned Fish', 'Tuna and sardine cans', 200, 'Food and Water'),
(1, 'Cooking Oil', '1L bottles of vegetable oil', 150, 'Food and Water'),
(1, 'Sugar', '1kg bags of white sugar', 400, 'Food and Water');


INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Electronics
(2, 'Smartphone', 'Latest model smartphone with 5G connectivity.', 50.0, 'Electronics'),
(2, 'Wireless Headphones', 'Noise-canceling wireless headphones.', 200.0, 'Electronics');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Medicine
(3, 'Ibuprofen', 'Pain relief and anti-inflammatory medication.', 150.0, 'Medicine'),
(3, 'Aspirin', 'Aspirin for pain relief and fever reduction.', 100.0, 'Medicine');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Clothing and Textiles
(4, 'Winter Jacket', 'Waterproof and insulated jacket for cold weather.', 75.0, 'Clothing and Textiles'),
(4, 'Thermal Socks', 'Insulated socks for keeping feet warm.', 200.0, 'Clothing and Textiles');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Personal Hygiene
(5, 'Toothbrush', 'Manual toothbrush for personal hygiene.', 500.0, 'Personal Hygiene'),
(5, 'Shampoo', 'Liquid shampoo for hair care.', 250.0, 'Personal Hygiene'),
(5, 'Soap Bars', '125g antibacterial soap bars', 300, 'Personal Hygiene'),
(5, 'Hand Sanitizer', '60ml bottles of alcohol-based hand sanitizer', 400, 'Personal Hygiene'),
(5, 'Toilet Paper', 'Rolls of soft toilet paper', 500, 'Personal Hygiene'),
(5, 'Tissues', 'Packs of soft facial tissues', 250, 'Personal Hygiene'),
(5, 'Deodorant', 'Roll-on deodorant sticks', 180, 'Personal Hygiene'),
(5, 'Wet Wipes', 'Packs of sanitizing wet wipes', 350, 'Personal Hygiene'),
(5, 'Feminine Hygiene Pads', 'Packs of sanitary pads', 200, 'Personal Hygiene'),
(5, 'Cotton Swabs', 'Packs of cotton swabs for cleaning', 100, 'Personal Hygiene');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- First Aid and Medical Supplies
(6, 'Gauze Pads', 'Sterile gauze pads for wound care.', 350.0, 'First Aid and Medical Supplies'),
(6, 'Bandages', 'Sterile bandages for wound protection and healing.', 295.0, 'First Aid and Medical Supplies');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Communication Devices
(7, 'Walkie Talkies', 'Two-way radios for communication in remote areas.', 50.0, 'Communication Devices'),
(7, 'Satellite Phone', 'Phone that works via satellite for remote communication.', 20.0, 'Communication Devices');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Power Generation and Lighting
(8, 'Solar Power Bank', 'Portable solar power bank for charging devices.', 80.0, 'Power Generation and Lighting'),
(8, 'LED Flashlight', 'High-power LED flashlight for emergencies.', 200.0, 'Power Generation and Lighting');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Tools and Equipment
(9, 'Hammer', 'Standard hammer for construction and repair tasks.', 100.0, 'Tools and Equipment'),
(9, 'Screwdriver Set', 'Comprehensive set of screwdrivers for various tasks.', 120.0, 'Tools and Equipment');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Baby and Childcare
(10, 'Diapers', 'Disposable diapers for infants.', 500.0, 'Baby and Childcare'),
(10, 'Baby Formula', 'Nutritional formula for babies.', 200.0, 'Baby and Childcare'),
(9, 'Wrench', 'Adjustable wrench for plumbing', 60, 'Tools and Equipment'),
(9, 'Tape Measure', '5-meter retractable tape measure', 90, 'Tools and Equipment'),
(9, 'Electric Drill', 'Cordless electric drill', 30, 'Tools and Equipment'),
(9, 'Pliers', 'Set of pliers for gripping and cutting', 100, 'Tools and Equipment'),
(9, 'Safety Gloves', 'Protective gloves for handling tools', 200, 'Tools and Equipment'),
(9, 'Screws and Nails', 'Assorted box of screws and nails', 500, 'Tools and Equipment'),
(9, 'Flashlight', 'LED flashlight with batteries', 120, 'Tools and Equipment'),
(9, 'Utility Knife', 'Sharp utility knife for cutting materials', 80, 'Tools and Equipment');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Pet Care
(11, 'Dog Food', 'Packaged dog food for pets.', 300.0, 'Pet Care'),
(11, 'Cat Litter', 'Absorbent litter for cat care.', 150.0, 'Pet Care');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Cleaning and Sanitation
(12, 'Printer Paper', 'High-quality printer paper for everyday printing needs.', 10.0, 'Cleaning and Sanitation'),
(12, 'Ink Cartridges', 'Black ink cartridges for office printers.', 20.0, 'Cleaning and Sanitation');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Furniture and Appliances
(13, 'Shelving Unit', 'A sturdy shelving unit for home or office storage.', 50.0, 'Furniture and Appliances'),
(13, 'Desk Lamp', 'A modern desk lamp with adjustable brightness.', 30.0, 'Furniture and Appliances');

INSERT INTO `products` (`prod_category_id`, `prod_item`, `prod_description`, `totalQuantity`, `prod_category`) VALUES
-- Recreational and Leisure
(14, 'Board Game', 'Popular board game for family entertainment.', 75.0, 'Recreational and Leisure'),
(14, 'Bicycle', 'Mountain bicycle for outdoor activities.', 25.0, 'Recreational and Leisure');


ALTER TABLE tasks AUTO_INCREMENT = 1;
-- Insert into tasks table with a variety of rescuers
INSERT INTO `tasks` (`task_prod_id`, `task_type`, `rescuer_id`) VALUES
(2, 'Offer', 1),   -- Offer task assigned to rescuer 1 for product 2
(3, 'Request', 2), -- Request task assigned to rescuer 2 for product 3
(4, 'Offer', 3),   -- Offer task assigned to rescuer 3 for product 4
(5, 'Request', 4), -- Request task assigned to rescuer 4 for product 5
(6, 'Offer', 5),   -- Offer task assigned to rescuer 5 for product 6
(1, 'Request', 6), -- Request task assigned to rescuer 6 for product 1
(2, 'Offer', 7),   -- Offer task assigned to rescuer 7 for product 2
(13, 'Request', 8), -- Request task assigned to rescuer 8 for product 3
(4, 'Offer', 1),   -- Offer task assigned to rescuer 1 for product 4
(5, 'Request', 2), -- Request task assigned to rescuer 2 for product 5
(1, 'Offer', 3),   -- Offer task assigned to rescuer 3 for product 1
(12, 'Request', 4), -- Request task assigned to rescuer 4 for product 2
(3, 'Offer', 5),   -- Offer task assigned to rescuer 5 for product 3
(4, 'Request', 6), -- Request task assigned to rescuer 6 for product 4
(5, 'Offer', 7),   -- Offer task assigned to rescuer 7 for product 5
(11, 'Request', 8); -- Request task assigned to rescuer 8 for product 1


-- Insert into offers table with offer_vehicle_id matching the rescuer's vehicle
INSERT INTO `offers` (`offer_task_id`, `offer_citizen_id`, `offer_date_record`, `offer_date_withdraw`, `offer_quantity`, `offer_vehicle_id`, `offer_status`, `offer_item`) VALUES
(1, 1, '2024-09-06 20:17:05', NULL, 20.0, 1, 'Accepted', 'Desk Lamp'),    -- Rescuer 1 with vehicle 1
(3, 3, '2024-09-06 20:17:05', NULL, 30.0, 3, 'Accepted', 'Bandages'),     -- Rescuer 3 with vehicle 3
(5, 5, '2024-09-06 20:17:05', '2024-09-14 17:31:46', 25.0, 5, 'Accepted', 'Ink Cartridges'), -- Rescuer 5 with vehicle 5
(7, 1, '2024-09-06 20:17:05', NULL, 10.0, 7, 'Accepted', 'Desk Lamp'),    -- Rescuer 7 with vehicle 7
(9, 1, '2024-09-06 20:17:05', NULL, 50.0, 1, 'Accepted', 'Bandages'),     -- Rescuer 1 with vehicle 1
(11, 6, '2024-09-06 20:17:05', NULL, 20.0, 3, 'Accepted', 'Shelving Unit'),-- Rescuer 3 with vehicle 3
(13, 2, '2024-09-06 20:17:05', '2024-09-14 17:14:59', 25.0, 5, 'Accepted', 'Aspirin'), -- Rescuer 5 with vehicle 5
(15, 4, '2024-09-06 20:17:05', NULL, 30.0, 7, 'Accepted', 'Printer Paper');-- Rescuer 7 with vehicle 7


-- Insert into requests table with req_vehicle_id matching the rescuer's vehicle
INSERT INTO `requests` (`req_task_id`, `req_citizen_id`, `req_date_record`, `req_date_withdraw`, `req_quantity`, `req_vehicle_id`, `req_status`, `req_item`) VALUES
(2, 2, '2024-09-06 20:17:33', NULL, 10.0, 2, 'Accepted', 'Aspirin'),      -- Rescuer 2 with vehicle 2
(4, 4, '2024-09-06 20:17:33', NULL, 15.0, 4, 'Accepted', 'Printer Paper'),-- Rescuer 4 with vehicle 4
(6, 5, '2024-09-06 20:17:33', NULL, 8.0, 6, 'Accepted', 'Shelving Unit'), -- Rescuer 6 with vehicle 6
(8, 2, '2024-09-06 20:17:33', NULL, 5.0, 8, 'Accepted', 'Aspirin'),       -- Rescuer 8 with vehicle 8
(10, 2, '2024-09-06 20:17:33', NULL, 12.0, 2, 'Accepted', 'Printer Paper'),-- Rescuer 2 with vehicle 2
(12, 3, '2024-09-06 20:17:33', NULL, 123.0, 4, 'Accepted', 'Desk Lamp'),  -- Rescuer 4 with vehicle 4
(14, 5, '2024-09-06 20:17:33', NULL, 8.0, 6, 'Accepted', 'Bandages'),     -- Rescuer 6 with vehicle 6
(16, 4, '2024-09-06 20:17:33', NULL, 30.0, 8, 'Accepted', 'Desk Lamp');   -- Rescuer 8 with vehicle 8



ALTER TABLE announcement AUTO_INCREMENT = 1;

INSERT INTO announcement (announcement_cat_id, announcement_prod_id, created_at, status) VALUES
(1, 1, '2024-09-08 08:00:00', 'Posted'),
(3, 5, '2024-09-08 12:30:00', 'Posted'),
(4, 7, '2024-09-08 14:45:00', 'Posted'),
(7, 13, '2024-09-08 19:00:00', 'Posted'),
(8, 16, '2024-09-08 21:00:00', 'Posted'),
(9, 17, '2024-09-08 21:30:00', 'Posted'),
(10, 19, '2024-09-08 23:00:00', 'Posted'),
(5, 9, '2024-09-08 16:00:00', 'Posted'),
(6, 11, '2024-09-08 18:10:00', 'Posted'),
(12, 23, '2024-09-09 01:00:00', 'Posted');


ALTER TABLE users  AUTO_INCREMENT = 1;

CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  user_type ENUM('admin', 'rescuer', 'citizen') NOT NULL,
  admin_id INT DEFAULT NULL,
  rescuer_id INT DEFAULT NULL,
  citizen_id INT DEFAULT NULL,
  FOREIGN KEY (admin_id) REFERENCES admin(admin_id) ON DELETE CASCADE,
  FOREIGN KEY (rescuer_id) REFERENCES rescuer(rescuer_id) ON DELETE CASCADE,
  FOREIGN KEY (citizen_id) REFERENCES citizen(citizen_id) ON DELETE CASCADE
);

-- Εισαγωγή πολιτών στον πίνακα users
INSERT INTO users (username, password, user_type, citizen_id)
SELECT username_citizen, password_citizen, 'citizen', citizen_id
FROM citizen;

-- Εισαγωγή διασωστών στον πίνακα users
INSERT INTO users (username, password, user_type, rescuer_id)
SELECT username_res, password_res, 'rescuer', rescuer_id
FROM rescuer;

-- Εισαγωγή διαχειριστών στον πίνακα users
INSERT INTO users (username, password, user_type, admin_id)
SELECT username_adm, password_adm, 'admin', admin_id
FROM admin;








