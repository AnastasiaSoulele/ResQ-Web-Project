document.addEventListener('DOMContentLoaded', function () {
  const sidebar = document.getElementById('sidebar');
  const menuBar = document.querySelector('#content nav .bx.bx-menu');

  // Διαχείριση εμφάνισης/κρυφής sidebar
  if (menuBar) {
      menuBar.addEventListener('click', function () {
          sidebar.classList.toggle('hide');
      });
  }

  // Διαχείριση sidebar visibility ανάλογα με το πλάτος του παραθύρου
  function handleSidebarVisibility() {
      if (window.innerWidth < 768) {
          sidebar.classList.add('hide');
      } else {
          sidebar.classList.remove('hide');
      }
  }

  handleSidebarVisibility();
  window.addEventListener('resize', handleSidebarVisibility);
});