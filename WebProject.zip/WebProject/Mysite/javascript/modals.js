document.addEventListener('DOMContentLoaded', (event) => {
  var modal = document.getElementById('terms-modal');
  var link = document.getElementById('terms-link');
  var span = document.getElementsByClassName('close')[0];


  link.onclick = function() {
      modal.style.display = 'block';
      return false; 
  }

  span.onclick = function() {
      modal.style.display = 'none';
  }

  window.onclick = function(event) {
      if (event.target === modal) {
          modal.style.display = 'none';
      }
  }

});


// Open Terms Modal
document.getElementById("terms-link").addEventListener("click", function () {
document.getElementById("terms-modal").style.display = "block";
});

// Close Terms Modal
document.querySelectorAll(".close").forEach(function (button) {
button.addEventListener("click", function () {
  button.closest(".modal").style.display = "none";
});
});